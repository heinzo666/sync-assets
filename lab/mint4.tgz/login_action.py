#!/usr/bin/env python3
"""Log into QuantumProxies by replicating the Next.js server action 'authenticate'."""
import json, secrets, re, sys, time

sys.path.insert(0, "/tmp/mintv3")
from qp_factory_v1 import sign   # guard signer (for X-QD headers)

B = "https://app.quantumproxies.io"
ACT = "7e73abdbb0e547db14bdf3ada96646b53b903e35a2"


def main():
    em = sys.argv[1]; pw = sys.argv[2]
    import requests
    s = requests.Session()
    H0 = {"user-agent": "Mozilla/5.0 Chrome/131", "accept-language": "en-US"}
    s.get(B + "/register", headers={**H0, "referer": B + "/"}, timeout=40)

    dev = secrets.token_hex(16)
    signed = sign(json.dumps({"usernameOrEmail": em})) or {}
    nstr = f"{signed.get('X-QD-TS','')}.{signed.get('X-QD-Token','')}"
    print("[dev]", dev[:10], "guardlen", len(nstr))

    base_hdr = {
        "accept": "text/x-component",
        "next-action": ACT,
        "origin": B,
        "referer": B + "/login",
        "user-agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"),
        "accept-language": "en-US,en;q=0.9",
    }
    variants = [
        ("arr_json", {"content-type": "application/json"},
         json.dumps([em, pw, nstr, True, "QP", dev])),
        ("arr_text", {"content-type": "text/plain;charset=UTF-8"},
         json.dumps([em, pw, nstr, True, "QP", dev])),
        ("obj_json", {"content-type": "application/json"},
         json.dumps([{"email": em, "password": pw, "captchaToken": nstr,
                      "rememberMe": True, "brand": "QP", "visitorId": dev}])),
    ]
    best = None
    for name, extra, payload in variants:
        try:
            r = s.post(B + "/login", data=payload.encode(), headers={**base_hdr, **extra},
                       allow_redirects=False, timeout=45)
            sc = r.headers.get("set-cookie", "")
            txt = r.text[:400].replace("\n", " ")
            print(f"\n[{name}] -> {r.status_code} setcookie={'Y' if sc else 'N'} len={len(r.text)}")
            print("   resp:", txt)
            if sc:
                print("   SC:", sc[:300])
            low = r.text.lower()
            hit = (r.status_code in (200, 201) and '"error"' not in low
                   and ('success' in low or 'dashboard' in low or 'session' in low))
            if hit:
                best = name
            sig = [k for k in ["invalid", "incorrect", "not verified", "security check"] if k in low]
            if sig:
                print("   ^ signal:", sig)
            time.sleep(3)
        except Exception as ex:
            print(f"[{name}] exc {type(ex).__name__}:{str(ex)[:90]}")
    print("\nbest=", best)
    print("cookies after:", [(c.name, c.value[:18]) for c in s.cookies])

    hh = {"accept": "application/json,*/*", "referer": B + "/dashboard"}
    for path in ("/api/v1/user/free-trial/status", "/api/v1/user"):
        rr = s.get(B + path, headers=hh, timeout=30)
        print(f"GET {path} -> {rr.status_code} {rr.text[:160].replace(chr(10),' ')}")
    out = {"best": best, "cookies": [(c.name, c.value) for c in s.cookies]}
    open("/tmp/mintv3/login_result.json", "w").write(json.dumps(out))


if __name__ == "__main__":
    main()
