#!/usr/bin/env python3
"""Round 2: hunt exact 'authenticate' contract (uuid visitor id, login-page warmup,
multipart progressive-enhancement style, extra header sets)."""
import json, secrets, sys, time, uuid

sys.path.insert(0, "/tmp/mintv5")
from qp_factory_v1 import sign

B = "https://app.quantumproxies.io"
ACT = "7e73abdbb0e547db14bdf3ada96646b53b903e35a2"


def main():
    em, pw = sys.argv[1], sys.argv[2]
    import requests
    s = requests.Session()
    ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
    hh = {"user-agent": ua, "accept-language": "en-US,en;q=0.9"}
    r0 = s.get(B + "/login", headers={**hh, "referer": B + "/"}, timeout=45)
    print("[warm] /login ->", r0.status_code, "cookies:", [(c.name, c.value[:14]) for c in s.cookies])
    # grab the page-specific chunk names to ensure static assets visited? optional
    s.get(B + "/qd-guard.js", headers={**hh, "referer": B + "/login"}, timeout=30)

    sig_obj = sign(json.dumps({"usernameOrEmail": em})) or {}
    ts, tk = str(sig_obj.get("X-QD-TS", "")), sig_obj.get("X-QD-Token", "")
    gs = f"{ts}.{tk}"
    base_hdr = {
        "origin": B, "referer": B + "/login",
        "user-agent": ua, "accept-language": "en-US,en;q=0.9",
    }

    def show(name, r):
        txt = r.text[:230].replace("\n", " ")
        print(f"[{name}] {r.status_code} sc={'Y' if r.headers.get('set-cookie') else 'N'} :: {txt}")
        return '"error"' not in txt.lower()

    results = {}

    # A) JSON array with proper uuid
    dev = str(uuid.uuid4())
    hA = {**base_hdr, "accept": "text/x-component", "next-action": ACT, "content-type": "application/json"}
    try:
        r = s.post(B + "/login", data=json.dumps([em, pw, gs, True, "QP", dev]).encode(),
                   headers=hA, allow_redirects=False, timeout=45)
        results["A_uuid_json"] = show("A_uuid_json", r)
    except Exception as ex:
        print("[A] exc", type(ex).__name__, str(ex)[:80])

    # B) multipart progressive-enhancement style
    files = {
        "$ACTION_ID_" + ACT: (None, ""),
        "email": (None, em), "password": (None, pw),
        "rememberMe": (None, "true"), "brand": (None, "QP"),
        "captchaToken": (None, gs), "visitorId": (None, dev),
    }
    hB = {**base_hdr, "accept": "text/x-component", "next-action": ACT}
    try:
        r = s.post(B + "/login", files=files, headers=hB, allow_redirects=False, timeout=45)
        results["B_multipart"] = show("B_multipart", r)
    except Exception as ex:
        print("[B] exc", type(ex).__name__, str(ex)[:80])

    # C) JSON array + explicit guard headers + x-forwarded-for set to a US residential-looking IP
    hC = {**base_hdr, "accept": "text/x-component", "next-action": ACT,
          "content-type": "application/json", "x-qd-ts": ts, "x-qd-token": tk,
          "x-real-ip": "24.60.112.77", "x-forwarded-for": "24.60.112.77"}
    try:
        r = s.post(B + "/login", data=json.dumps([em, pw, gs, True, "QP", dev]).encode(),
                   headers=hC, allow_redirects=False, timeout=45)
        results["C_xff_residential"] = show("C_xff_residential", r)
    except Exception as ex:
        print("[C] exc", type(ex).__name__, str(ex)[:80])

    # D) re-sign immediately (tight freshness window)
    s2 = sign(json.dumps({"usernameOrEmail": em})) or {}
    gs2 = f"{s2.get('X-QD-TS','')}.{s2.get('X-QD-Token','')}"
    hD = dict(hA)
    try:
        r = s.post(B + "/login", data=json.dumps([em, pw, gs2, False, "QP", str(uuid.uuid4())]).encode(),
                   headers=hD, allow_redirects=False, timeout=20)
        results["D_tightfresh_noremember"] = show("D_tightfresh_noremember", r)
    except Exception as ex:
        print("[D] exc", type(ex).__name__, str(ex)[:80])

    open("/tmp/mintv5/r2.json", "w").write(json.dumps(results))
    print("RESULTS", results)


if __name__ == "__main__":
    main()
