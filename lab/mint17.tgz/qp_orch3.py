#!/usr/bin/env python3
"""QP activation orchestrator v2 — pod side.
Reads target addr from GH, runs browser signup (+slider), waits for verify artifact
(code/link published by our local watcher to GH), verifies, logs in, claims trial,
pushes a result row to GH."""
import base64, json, os, secrets, sys, time

B = "https://app.quantumproxies.io"
GHTOK_FILE = "/tmp/.ghtok"
REPO = "heinzo666/sync-assets"


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def sw(pg, ms):
    try:
        pg.wait_for_timeout(ms)
        return True
    except Exception as ex:
        log(f"[sw] {type(ex).__name__}:{str(ex)[:60]}")
        return False


def gh_req(method, path, body=None):
    import urllib.request
    tok = open(GHTOK_FILE).read().strip()
    url = f"https://api.github.com/repos/{REPO}/contents/{path}"
    req = urllib.request.Request(url, method=method,
                                 data=(json.dumps(body).encode() if body else None),
                                 headers={"Authorization": "Bearer " + tok,
                                          "Accept": "application/vnd.github+json",
                                          "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode()), r.status


def gh_get_text(path):
    try:
        d, _ = gh_req("GET", path)
        return base64.b64decode(d["content"]).decode(), d.get("sha")
    except Exception:
        return None, None


def gh_put_text(path, text, msg):
    cur, sha = gh_get_text(path)
    body = {"message": msg, "content": base64.b64encode(text.encode()).decode()}
    if sha:
        body["sha"] = sha
    try:
        _, st = gh_req("PUT", path, body)
        return st
    except Exception as ex:
        return f"ERR:{type(ex).__name__}"


def ncc_x(bgpng_bytes, pcbytes):
    import io, numpy as np
    from PIL import Image

    def arr(b):
        im = Image.open(io.BytesIO(b)).convert("RGBA")
        return np.asarray(im).astype(np.float32)

    bg, pc = arr(bgpng_bytes), arr(pcbytes)
    alpha = pc[:, :, 3] > 60
    ys, xs = np.where(alpha)
    if len(xs) == 0:
        return 0.0, 0
    pcc = pc[ys.min():ys.max()+1, xs.min():xs.max()+1]
    pmask = pcc[:, :, 3:4] > 100
    rr = pcc[:, :, :3] * pmask
    norm = float((rr ** 2).sum()) ** 0.5 + 1e-6
    H, W = bg.shape[0], bg.shape[1]
    h, w = rr.shape[0], rr.shape[1]
    sx = max(1, (W - w) // 200)
    sy = max(1, (H - h) // 40) if H > h else 1
    best, bx = -9.0, 0
    for yy in range(0, max(1, H - h), sy):
        band = bg[yy:yy+h, :, :3]
        if band.shape[0] != h:
            continue
        for xx in range(0, max(1, W - w), sx):
            win = band[:, xx:xx+w, :]
            num = float((win * rr).sum())
            den = (float((win ** 2).sum()) ** 0.5 + 1e-6) * norm
            sc = num / den
            if sc > best:
                best, bx = sc, xx
    return best, int(bx)


def main():
    tag = sys.argv[1]
    stage = os.environ.get("STAGE", "full")
    log(f"=== orchv2 {tag} ===")
    txt, _ = gh_get_text(f"lab/qaddr_{tag}.json")
    if not txt:
        log("no qaddr file"); return
    info = json.loads(txt)
    em, pw = info["email"], info["pw"]
    rec = {"tag": tag, "email": em, "pw": pw, "ts": int(time.time()), "stages": {}}

    cap_json_log = {}
    netresps = []
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        br = p.chromium.launch(headless=True,
                               args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
        ctx = br.new_context(locale="en-US",
                             user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                                         "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"),
                             viewport={"width": 1440, "height": 810})

        def on_resp(r):
            u = r.url
            if "/api/v1/auth/captcha" in u and "check" not in u:
                try:
                    pl = (r.json() or {}).get("payload") or {}
                    if pl.get("background") and pl.get("pieceImage"):
                        cap_json_log.clear(); cap_json_log.update(pl)
                        log("captcha challenge captured")
                except Exception:
                    pass

        def rec_resp(r):
            u = r.url
            if any(k in u for k in ("auth/signup", "/register", "/login", "free-trial", "verify-email")):
                try:
                    t = r.text()[:380].replace("\n", " ")
                except Exception:
                    t = ""
                netresps.append({"st": r.status, "u": u[-70:], "t": t})
        

        pg = ctx.new_page()
        pg.on("response", on_resp)
        pg.on("response", rec_resp)

        # ---------- SIGNUP ----------
        pg.goto(B + "/register", wait_until="domcontentloaded", timeout=60000)
        sw(pg, 2400)
        ins = pg.eval_on_selector_all("input", "els=>els.map(e=>({n:e.name,t:e.type}))")
        rec["stages"]["inputs"] = ins
        log(f"inputs {ins}")
        pg.fill("input[name=email]", em, timeout=15000)
        pwsel = "input[name=password]" if pg.query_selector("input[name=password]") else "input[name*=pass i]"
        pg.fill(pwsel, pw, timeout=8000)
        c = pg.query_selector("input[name=confirmPassword]")
        if c:
            c.fill(pw)
        for cb in pg.query_selector_all("input[type=checkbox]"):
            try:
                if not cb.is_checked():
                    cb.check(timeout=3000)
            except Exception:
                pass
        # consent controls first (labels mentioning agree/terms/privacy)
        try:
            for lab in pg.query_selector_all("label, div"):
                tx = ((lab.inner_text() or "")[:80]).lower()
                if any(w in tx for w in ("agree", "terms", "privacy", "gdpr")):
                    for ctl in lab.query_selector_all("input,button,[role=checkbox],[role=switch]"):
                        try:
                            sel = ctl.get_attribute("aria-checked")
                            if ctl.is_enabled():
                                ctl.check() if ctl.evaluate("e=>e.tagName==='INPUT'") else None
                                if ctl.evaluate("e=>e.tagName!=='INPUT'"):
                                    ctl.click()
                        except Exception:
                            pass
                    break
        except Exception:
            pass
        btn = pg.query_selector("//button[contains(normalize-space(),'Create') or contains(normalize-space(),'Sign Up') or contains(normalize-space(),'Register')]") \
              or pg.query_selector("button[type=submit]:not(:has-text('English'))")
        btn.click(timeout=12000)
        sw(pg,1500)
        su_errs=[]
        for el in pg.query_selector_all("[role=alert], [id$='-error'], [class*=error i], [data-slot=error]"):
            try:
                tt=(el.inner_text() or "").strip().replace("\n"," ")
                if tt and len(tt)<160 and tt not in su_errs:
                    su_errs.append(tt)
            except Exception: pass
        rec["stages"]["su_errs"]=su_errs[:8]
        rec["stages"]["su_resps"]=[x for x in netresps][-6:]
        log(f"signup submitted errs={su_errs[:4]} posts={len([x for x in netresps if 'signup' in x['u'] or 'register' in x['u']])}")

        solved = False
        t0 = time.time()
        while time.time() - t0 < 95:
            sw(pg, 900)
            if "/login" in pg.url or "/dashboard" in pg.url or "verify" in pg.url.lower():
                break
            if cap_json_log and not solved:
                import base64 as b64mod
                try:
                    score, xpx = ncc_x(b64mod.b64decode(cap_json_log["background"].split(",")[-1]),
                                       b64mod.b64decode(cap_json_log["pieceImage"].split(",")[-1]))
                    log(f"solve ncc={score:.3f} x={xpx}")
                    bb = kb = None
                    for i in pg.query_selector_all("img"):
                        src = i.get_attribute("src") or ""
                        if src.startswith("data:image"):
                            b = i.bounding_box()
                            if b and b["width"] > 170:
                                bb = b; break
                    for sel in ("[role=slider]", ".react-slider", "[draggable=true]",
                                "div[class*=handle i]", "div[class*=knob i]", "span[class*=thumb i]"):
                        el = pg.query_selector(sel)
                        if el:
                            b = el.bounding_box()
                            if b:
                                kb = b; break
                    rec["stages"]["geom"] = {"bb": bool(bb), "kb": bool(kb)}
                    if bb and kb:
                        sx = kb["x"] + kb["width"]/2; sy = kb["y"] + kb["height"]/2
                        dx = xpx * (bb["width"] / float(cap_json_log["width"]))
                        pg.mouse.move(sx, sy); pg.mouse.down()
                        steps = 26
                        for st in range(1, steps+1):
                            pg.mouse.move(sx + dx*st/steps, sy + ((-1)**st)*0.7)
                            pg.wait_for_timeout(24 + st % 5)
                        pg.mouse.up(); solved = True
                        log(f"drag +{dx:.0f}px scale={bb['width']/float(cap_json_log['width']):.2f}")
                        sw(pg, 2800)
                    else:
                        log("geometry missing; will retry next tick")
                except Exception as ex:
                    log(f"solve exc {type(ex).__name__}:{str(ex)[:70]}")

        rec["stages"]["url_signup"] = pg.url
        ls = pg.evaluate("Object.fromEntries(Object.entries(localStorage))")
        rec["stages"]["tok_signup"] = bool(ls.get("token"))
        log(f"post-signup {pg.url} tok={rec['stages']['tok_signup']}")
        if stage == "signup":
            finish(br, rec); return

        # ---------- VERIFY VIA GH RELAY ----------
        got = None
        vt = time.time()
        while time.time() - vt < 230:
            t2, _ = gh_get_text(f"lab/mcode_{tag}.txt")
            if t2 and ("CODE=" in t2 or "LINK=" in t2):
                gg = dict(x.split("=", 1) for x in t2.strip().splitlines() if "=" in x)
                if any((v or "").strip() not in ("", "-") for v in gg.values()):
                    got = gg
                    log(f"relay arrived keys={list(got)}")
                    break
            sw(pg, 4500)
        rec["stages"]["mail_relay"] = bool(got)
        if got:
            link = got.get("LINK")
            code = got.get("CODE")
            try:
                if link and link != "-":
                    pg.goto(link, wait_until="domcontentloaded", timeout=50000)
                    log(f"opened link -> {pg.url}")
                elif code and code != "-":
                    pg.goto(B + "/verify-email", wait_until="domcontentloaded", timeout=45000)
                    sw(pg, 1600)
                    inp = pg.query_selector("input[inputmode=numeric], input[maxlength='6'], input[name*=code i]")
                    if inp:
                        inp.fill(code)
                        sb = pg.query_selector("button[type=submit]:not(:has-text('English'))")
                        if sb:
                            sb.click()
                        log("verify code submitted")
                sw(pg, 3800)
            except Exception as ex:
                log(f"verify exc {type(ex).__name__}:{str(ex)[:80]}")
        rec["stages"]["url_postverify"] = pg.url

        # ---------- LOGIN ----------
        tokval = None
        try:
            pg.goto(B + "/login", wait_until="domcontentloaded", timeout=50000)
            sw(pg, 2600)
            pg.fill("input[name=email]", em, timeout=14000)
            pg.fill("input[name=password]", pw, timeout=8000)
            lb = pg.query_selector("//button[normalize-space()='Log In']") or pg.query_selector("button:has-text('Log In')")
            lb.click(timeout=12000)
            lt = time.time()
            errs = []
            while time.time() - lt < 90:
                sw(pg, 1300)
                tokval = pg.evaluate("localStorage.getItem('token')")
                if tokval or "/dashboard" in pg.url:
                    break
                e = pg.query_selector("text=/invalid|incorrect|verif|wrong/i")
                if e and e.is_visible():
                    tx = ((e.inner_text() or "")[:80]).replace("\n", " ")
                    if tx and tx not in errs:
                        errs.append(tx)
                        if len(errs) >= 3:
                            break
            rec["stages"]["login_url"] = pg.url
            rec["stages"]["login_errs"] = errs
            rec["stages"]["tok_login"] = bool(tokval)
        except Exception as ex:
            rec["stages"]["login_exc"] = f"{type(ex).__name__}:{str(ex)[:110]}"

        # ---------- CLAIM + PROBE ----------
        apis = {}
        if tokval or "/dashboard" in pg.url:
            paths_probe = ["/api/v1/user/free-trial/status", "/api/v1/user",
                           "/api/v1/residential-basic/whitelist",
                           "/api/v1/user/balance-history?limit=1"]
            for a in paths_probe:
                apis[a] = pg.evaluate(
                    """async (path)=>{try{
                       const t=localStorage.getItem('token');
                       const h=t?{authorization:'Bearer '+t,accept:'application/json,*/*'}
                               :{accept:'application/json,*/*'};
                       const r=await fetch(path,{credentials:'include',headers:h});
                       return {code:r.status,body:(await r.text()).slice(0,300)};}
                       catch(e){return{err:String(e).slice(0,70)}}}""", a)
            # signed POST helper executed inside real browser (genuine guard runtime)
            claim = pg.evaluate(
                """async ()=>{
                   try{
                     const body={};
                     const s=JSON.stringify(body);
                     const g=window.qdGuard ? window.qdGuard.sign(s) : null;
                     const h={'content-type':'application/json','accept':'application/json,*/*'};
                     if(g){h['X-QD-TS']=String(g.ts); h['X-QD-Token']=g.token;}
                     const t=localStorage.getItem('token'); if(t) h.authorization='Bearer '+t;
                     const r=await fetch('/api/v1/user/free-trial/claim',
                        {method:'POST',credentials:'include',headers:h,body:s});
                     return {code:r.status,body:(await r.text()).slice(0,400)};
                   }catch(e){return{err:String(e).slice(0,90)}}"""
            )
            rec["stages"]["apis"] = apis
            rec["stages"]["claim_inpage"] = claim
            log(f"claim -> {json.dumps(claim)[:180]}")
        pg.screenshot(path=f"/tmp/orch2_{tag}.png")
        br.close()

    finish(None, rec)


def finish(br, rec):
    if br:
        try:
            br.close()
        except Exception:
            pass
    outp = "/tmp/orch_results.jsonl"
    open(outp, "a").write(json.dumps(rec) + "\n")
    prev, _ = gh_get_text("lab/orch_out.jsonl")
    payload = (prev + "\n" if prev else "") + json.dumps(rec) + "\n"
    st = gh_put_text("lab/orch_out.jsonl", payload, f"orch {rec.get('tag')}")
    short = {"tag": rec.get("tag"), "push": st}
    stg = rec.get("stages", {})
    short.update({"signup": stg.get("url_signup"), "tok_su": stg.get("tok_signup"),
                  "relay": stg.get("mail_relay"), "login": stg.get("login_url"),
                  "tok_lg": stg.get("tok_login"), "errs": stg.get("login_errs"),
                  "claim": str(stg.get("claim_inpage"))[:120],
                  "api_codes": {k: v.get("code") for k, v in (stg.get("apis") or {}).items()},
                  "exc": stg.get("login_exc") or rec.get("error")})
    log("SUMMARY " + json.dumps(short)[:760])


if __name__ == "__main__":
    main()
