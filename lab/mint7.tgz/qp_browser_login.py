#!/usr/bin/env python3
"""Single exploratory browser login against QuantumProxies; dumps everything useful."""
import json, sys, time, re

B = "https://app.quantumproxies.io"


def main():
    em, pw = sys.argv[1], sys.argv[2]
    from playwright.sync_api import sync_playwright

    nets = []

    def keep(r):
        u = r.url
        if any(k in u for k in ("/api/", "/login", "/qd-guard", "signup", "captcha")) and \
           not u.endswith((".css", ".png", ".woff2", ".svg")):
            rec = {"m": r.method, "u": u[:180]}
            try:
                pd = r.post_data
                if pd:
                    rec["body"] = pd[:900]
            except Exception:
                pass
            rec["hdr_action"] = (r.headers.get("next-action") or "")[:40]
            nets.append(rec)

    rep = {}
    with sync_playwright() as p:
        br = p.chromium.launch(headless=True,
                               args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
        ctx = br.new_context(locale="en-US",
                             user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                         "AppleWebKit/537.36 (KHTML, like Gecko) "
                                         "Chrome/131.0.0.0 Safari/537.36"),
                             viewport={"width": 1440, "height": 810})
        pg = ctx.new_page()
        pg.on("request", keep)
        try:
            pg.goto(B + "/login", wait_until="domcontentloaded", timeout=60000)
            pg.wait_for_timeout(3500)

            # discover form fields
            ins = pg.eval_on_selector_all(
                "input", "els=>els.map(e=>({name:e.name,type:e.type,id:e.id}))")
            btns = pg.eval_on_selector_all(
                "button", "els=>els.slice(0,8).map(e=>({t:(e.innerText||'').trim().slice(0,20),type:e.type}))")
            rep["inputs"] = ins
            rep["buttons"] = btns
            print("[form]", json.dumps({"inputs": ins, "buttons": btns})[:400])

            e_sel = "input[type=email]" if any(i["type"] == "email" for i in ins) else \
                ("input[name*=mail]" if any("mail" in str(i.get("name")) for i in ins) else "input#email")
            p_sel = "input[type=password]"
            pg.fill(e_sel, em, timeout=15000)
            pg.fill(p_sel, pw, timeout=10000)
            print("[filled]", e_sel, p_sel)

            sub = "button[type=submit]" if any(b["type"] == "submit" for b in btns) else "button:has-text(/Sign|Log/i)"
            pg.click(sub, timeout=12000)
            print("[clicked submit]")

            # watch up to 45s for redirect / captcha / error toast
            deadline = time.time() + 50
            while time.time() < deadline:
                pg.wait_for_timeout(800)
                u = pg.url
                if "/dashboard" in u:
                    break
                capdet = pg.query_selector("text=/slide|puzzle|captcha/i")
                if capdet:
                    print("[captcha visible]", (capdet.inner_text() or "")[:80])
                    break
            rep["url"] = pg.url
            try:
                rep["title"] = pg.title()
            except Exception:
                pass

            # scrape storage/cookies whenever we are anywhere meaningful
            try:
                rep["ls"] = pg.evaluate("Object.fromEntries(Object.entries(localStorage))")
            except Exception:
                rep["ls"] = {}
            rep["cookies"] = [(c["name"], c["value"][:28]) for c in ctx.cookies()]
            try:
                rep["html_snip"] = pg.content()[:500].replace("\n", " ")
            except Exception:
                pass
            pg.screenshot(path="/tmp/login_last.png")

            # if landed in dashboard -> probe APIs from page context (same-origin+cookies)
            if "/dashboard" in pg.url or rep["ls"].get("token"):
                apis = ["/api/v1/user/free-trial/status", "/api/v1/user",
                        "/api/v1/user/balance-history?limit=1"]
                got = {}
                for a in apis:
                    got[a] = pg.evaluate(
                        """async (path)=>{try{
                            const r=await fetch(path,{credentials:'include',headers:{accept:'application/json,*/*'}});
                            return {code:r.status, body:(await r.text()).slice(0,300)};}catch(e){return {err:String(e).slice(0,90)}}}""",
                        a)
                rep["apis"] = got
        except Exception as ex:
            rep["exc"] = f"{type(ex).__name__}: {str(ex)[:160]}"

        br.close()

    rep["nets"] = nets[-16:]
    open("/tmp/browser_result.json", "w").write(json.dumps(rep))
    print("\nRESULT_JSON_START")
    print(json.dumps({k: v for k, v in rep.items() if k != "html_snip"}, indent=1)[:2600])
    print("RESULT_JSON_END")


if __name__ == "__main__":
    main()
