#!/usr/bin/env python3
"""Probe the exact arg/header contract for QP's 'authenticate' server action."""
import json, secrets, sys, time

sys.path.insert(0, "/tmp/mintv4")
from qp_factory_v1 import sign

B = "https://app.quantumproxies.io"
ACT = "7e73abdbb0e547db14bdf3ada96646b53b903e35a2"


def main():
    em, pw = sys.argv[1], sys.argv[2]
    import requests
    s = requests.Session()
    s.get(B + "/register", headers={"user-agent": "Mozilla/5.0 Chrome/131"}, timeout=40)
    sig_obj = sign(json.dumps({"usernameOrEmail": em})) or {}
    ts, tk = str(sig_obj.get("X-QD-TS", "")), sig_obj.get("X-QD-Token", "")
    sig_empty = sign("{}") or {}

    hdr_common = {
        "accept": "text/x-component",
        "next-action": ACT,
        "origin": B,
        "referer": B + "/login",
        "content-type": "application/json",
        "user-agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"),
    }

    def attempt(name, args, extra_hdr=None):
        dev = secrets.token_hex(16)
        payload = json.dumps([a.format(DEV=dev) if isinstance(a, str) else a for a in args])
        try:
            r = s.post(B + "/login", data=payload.encode(),
                       headers={**hdr_common, **(extra_hdr or {})},
                       allow_redirects=False, timeout=45)
            txt = r.text[:260].replace("\n", " ")
            print(f"[{name}] {r.status_code} sc={'Y' if r.headers.get('set-cookie') else 'N'} :: {txt}")
            return '"error"' not in txt.lower() and 'success' in txt.lower()
        except Exception as ex:
            print(f"[{name}] exc {type(ex).__name__}:{str(ex)[:70]}")
            return False

    combos = [
        # ts/token also as explicit headers, combined string as 3rd arg
        ("H+combined", [em, pw, f"{ts}.{tk}", True, "QP", "{DEV}"],
         {"x-qd-ts": ts, "x-qd-token": tk}),
        # six scalars after email/pw
        ("split-scalars", [em, pw, ts, tk, True, "QP", "{DEV}"]),
        # no guard value at all
        ("noguard", [em, pw, "", True, "QP", "{DEV}"]),
        # sign an empty object instead
        ("empty-sign", [em, pw, f"{sig_empty.get('X-QD-TS','')}.{sig_empty.get('X-QD-Token','')}", True, "QP", "{DEV}"]),
        # object-with-all-fields including guard headers inline
        ("obj-full", [{"email": em, "password": pw, "rememberMe": True, "brand": "QP",
                       "captchaToken": f"{ts}.{tk}", "visitorId": "{DEV}"}]),
    ]
    for c in combos:
        hit = attempt(*c)
        if hit:
            print("*** SUCCESS VARIANT:", c[0])
            open("/tmp/mintv4/login_win.txt", "w").write(json.dumps(
                {"variant": c[0], "args": [x if isinstance(x, str) else "...obj..." for x in c[1]]}))
            break
        time.sleep(2)


if __name__ == "__main__":
    main()
