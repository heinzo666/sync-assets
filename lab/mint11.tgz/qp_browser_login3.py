#!/usr/bin/env python3
"""v3: same as v2 but records server RESPONSES for auth endpoints."""
import json, sys, time

B = "https://app.quantumproxies.io"


def main():
    em, pw = sys.argv[1], sys.argv[2]
    from playwright.sync_api import sync_playwright

    reqs, resps = [], []

    def keep_req(r):
        u = r.url
        if ("/api/" in u or u.rstrip("/").endswith("/login")) and \
           not u.endswith((".css", ".png", ".woff2", ".svg", ".js")):
            rec = {"m": r.method, "u": u[:150]}
            try:
                pd = r.post_data
                if pd:
                    rec["body"] = pd[:500]
            except Exception:
                pass
            na = r.headers.get("next-action")
            if na:
                rec["na"] = na[:20]
            reqs.append(rec)

    def keep_resp(r):
        u = r.url
        if "/login" in u or "/api/auth/" in u or "captcha" in u or "free-trial" in u:
            rec = {"u": u[:130], "st": r.status}
            try:
                t = r.text()
                rec["t"] = t[:420].replace("\n", " ")
            except Exception:
                pass
            resps.append(rec)

    rep = {}
    with sync_playwright() as p:
        br = p.chromium.launch(headless=True,
                               args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
        ctx = br.new_context(locale="en-US",
                             user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                         "AppleWebKit/537.36 (KHTML, like Gecko) "
                                         "Chrome/131.0.0.0 Safari/537.36"),
                             viewport={"width": 1440, "height": 810})
        pg = ctx.new_page()
        pg.on("request", keep_req)
        pg.on("response", keep_resp)
        try:
            pg.goto(B + "/login", wait_until="domcontentloaded", timeout=60000)
            pg.wait_for_timeout(2800)
            pg.fill("input[name=email]", em, timeout=15000)
            pg.fill("input[name=password]", pw, timeout=8000)
            btn = pg.query_selector("//button[normalize-space()='Log In']") or pg.query_selector("button:has-text('Log In')")
            btn.click(timeout=12000)
            print("[clicked]")

            tok = None; t0 = time.time(); last_url = ""
            while time.time() - t0 < 115:
                pg.wait_for_timeout(1400)
                if pg.url != last_url:
                    print("[url]", pg.url); last_url = pg.url
                tok = pg.evaluate("localStorage.getItem('token')")
                if tok or "/dashboard" in pg.url:
                    break
                # look for visible inline errors anywhere
                err = pg.query_selector("text=/invalid|incorrect|verif|wrong|failed/i")
                if err and err.is_visible():
                    tx = ((err.inner_text() or "")[:100]).replace("\n", " ")
                    if "invalid date" not in tx.lower():
                        print("[vis-error]", tx)
                        rep.setdefault("inline_err", []).append(tx)
                        if len(rep["inline_err"]) > 4:
                            break
            rep["tok"] = bool(tok)
            rep["final_url"] = pg.url
            rep["title"] = pg.title()
            try:
                body_txt = pg.inner_text("body")
                rep["tail_text"] = body_txt[-700:]
            except Exception:
                pass
        except Exception as ex:
            rep["exc"] = f"{type(ex).__name__}: {str(ex)[:180]}"
        br.close()

    rep["resps_auth"] = [r for r in resps if "/login" in r["u"] or "/auth/" in r["u"]][-8:]
    rep["resps_all_n"] = len(resps)
    open("/tmp/browser_result.json", "w").write(json.dumps(rep))
    print("OUT " + json.dumps({k: v for k, v in rep.items() if k != "tail_text"})[:2200])
    print("TAILTXT " + (rep.get("tail_text", "")[-320:]).replace("\n", " "))


if __name__ == "__main__":
    main()
