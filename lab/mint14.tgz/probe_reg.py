#!/usr/bin/env python3
"""Find a working chromium arg set for QP's app pages."""
import json, sys, time

B = "https://app.quantumproxies.io"

VARIANTS = [
    ("base", ["--no-sandbox", "--disable-dev-shm-usage"]),
    ("swrast_off", ["--no-sandbox", "--disable-dev-shm-usage",
                    "--disable-gpu-compositing", "--disable-software-rasterizer"]),
    ("feature_cut", ["--no-sandbox", "--disable-dev-shm-usage",
                     "--disable-features=IsolateOrigins,site-per-process,RendererCodeIntegrity",
                     "--js-flags=--max-old-space-size=512"]),
]


def main():
    url = sys.argv[1] if len(sys.argv) > 1 else B + "/register"
    from playwright.sync_api import sync_playwright
    results = []
    with sync_playwright() as p:
        for name, args in VARIANTS:
            r = {"name": name}
            try:
                br = p.chromium.launch(headless=True, args=args)
                ctx = br.new_context(locale="en-US")
                pg = ctx.new_page()
                errs = []
                pg.on("pageerror", lambda e: errs.append(str(e)[:100]))
                pg.on("crash", lambda _pg: errs.append("CRASH_EVENT"))
                t0 = time.time()
                pg.goto(url, wait_until="domcontentloaded", timeout=45000)
                r["title"] = pg.title()
                pg.wait_for_timeout(4000)
                r["alive_after_wait"] = True
                r["inputs"] = pg.eval_on_selector_all(
                    "input", "els=>els.map(e=>e.name)")
                r["ms"] = int((time.time() - t0) * 1000)
                br.close()
            except Exception as ex:
                r["exc"] = f"{type(ex).__name__}:{str(ex)[:120]}"
                try:
                    br.close()
                except Exception:
                    pass
            r["errs"] = locals().get("errs", [])[:4]
            results.append(r)
            print(json.dumps(r))
            # success -> stop early once a variant passes everything incl eval
            if r.get("alive_after_wait") and "exc" not in r:
                break
    open("/tmp/probe_reg.json", "w").write(json.dumps(results))


if __name__ == "__main__":
    main()
