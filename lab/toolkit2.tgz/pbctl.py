#!/usr/bin/env python3
"""pbctl — execute bash batches on pulsarbeyond via StyleSmuggler run-big."""
import base64, os, secrets, sys, time

R = "/home/gabri/.hermes/dionysus-pi/workspace-root"
sys.path.insert(0, f"{R}/work/recon/mag")
for v in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY"):
    os.environ.pop(v, None)
import runbig as RB   # patched client already


def _wrap_php(bash_cmd):
    b = base64.b64encode(bash_cmd.encode()).decode()
    return (
        "$c=base64_decode('" + b + "');"
        "ob_start();passthru($c,$rc);$o=ob_get_clean();"
        "echo \"<<<PB>>>\";echo base64_encode((string)$o).\"|\".intval($rc);"
    )


def run_bash(cmd, tries=6, label=""):
    php = _wrap_php(cmd)
    for i in range(tries):
        t0 = time.time()
        try:
            out = str(RB.run_big(php))
        except Exception as ex:
            print(f"[pbctl {label}] exc {type(ex).__name__}:{str(ex)[:80]} ({int(time.time()-t0)}s)",
                  flush=True)
            time.sleep(4)
            continue
        if "<<<PB>>>" in out:
            seg = out.split("<<<PB>>>", 1)[1].strip().splitlines()[0]
            try:
                b64, rc = seg.rsplit("|", 1)
                data = base64.b64decode(b64).decode(errors="replace")
                return {"ok": True, "out": data, "rc": int(float(rc)), "secs": round(time.time() - t0)}
            except Exception as ex:
                print(f"[pbctl] parse err {ex}", flush=True)
        else:
            print(f"[pbctl {label}] miss({int(time.time()-t0)}s): {out[:120]}", flush=True)
        time.sleep(5)
    return {"ok": False}


if __name__ == "__main__":
    import os as _os
    arg = sys.argv[1] if len(sys.argv) > 1 else ""
    cmd = open(arg).read() if arg and _os.path.exists(arg) else (arg or "id; hostname")
    r = run_bash(cmd, label="cli")
    print(r.get("out") or "(none)", "\n[rc]", r.get("rc"), "[ok]", r.get("ok"))
