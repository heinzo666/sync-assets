import base64, io, json, secrets, sys, time

import numpy as np
from PIL import Image
import requests as creq

PX = None                      # DIRECT pod egress first try
BASE = "https://app.quantumproxies.io"
OUTF = "/tmp/lab/qpres.json"


def dec(u): return base64.b64decode(u.split(",", 1)[1])


def ncc(bg_bytes, pc_bytes):
    A = np.asarray(Image.open(io.BytesIO(bg_bytes)).convert("L"), dtype=np.float32)
    pm = Image.open(io.BytesIO(pc_bytes)); cr = pm.crop(pm.getbbox())
    T0 = np.asarray(cr.convert("L"), dtype=np.float32); al = np.asarray(cr.split()[-1], dtype=np.float32)
    m = (al > 110).astype(np.float32); th, tw = T0.shape
    tv = T0[m > 0]; mu, sd = float(tv.mean()), float(tv.std()) + 1e-6
    T = (T0 - mu) * m / sd
    from numpy.fft import rfft2, irfft2
    ph, pwd = A.shape[0] + th - 1, A.shape[1] + tw - 1
    cv = irfft2(rfft2(A, s=(ph, pwd)) * rfft2(T[::-1, ::-1], s=(ph, pwd)), s=(ph, pwd))
    v = cv[th-1:, tw-1:]
    idx = np.argsort(-v.ravel())[:50]
    best = (-9, 30, 30)
    for i in idx:
        y, x = int(i // v.shape[1]), int(i % v.shape[1])
        w = A[y:y+th, x:x+tw]
        if w.shape != (th, tw): continue
        vv = w[m > 0]
        Bz = (w - float(vv.mean())) * m / (float(vv.std()) + 1e-6)
        r = float((Bz * T).sum()) / m.sum()
        if r > best[0]: best = (r, x, y)
    return best


def trace(x_end):
    st = -(secrets.randbelow(14)+4); ov=[0,1,-1][secrets.randbelow(3)]
    end=x_end+ov; npts=62+secrets.randbelow(26); dur=980+secrets.randbelow(470)
    t=int(time.time()*1000)-dur-secrets.randbelow(240)
    ez=lambda u:(4*u**3 if u<.5 else 1-((-2*u+2)**3)/2)
    tr=[]
    for i in range(npts+1):
        jx=st+(end-st)*ez(i/npts)+(secrets.randbelow(220)-110)/160.0*(1-i/(npts+1))
        tt=t+int(dur*i/npts)+secrets.randbelow(12)-6
        if tr and tt<=tr[-1]["t"]: tt=tr[-1]["t"]+1+secrets.randbelow(15)
        tr.append({"x":round(jx,2),"t":tt})
    tr.append({"x":float(max(0,x_end)),"t":tr[-1]["t"]+10+secrets.randbelow(34)})
    return tr[:400]


res={"tries":[]}
try:
    s=creq.Session()
    H={"accept":"application/json, text/plain, */*","referer":BASE+"/register",
       "sec-ch-ua":'"Chromium";v="131", "Not_A Brand";v="24"',"sec-ch-ua-mobile":"?0",
       "sec-ch-ua-platform":'"Windows"',"sec-fetch-dest":"empty","sec-fetch-mode":"cors","sec-fetch-site":"same-origin"}
    ip=s.get("https://api.ipify.org",timeout=20).text.strip()
    res["pod_ip"]=ip
    s.get(BASE+"/register",headers={**H,"referer":"https://quantumproxies.io/"},timeout=40)
    g=s.get(BASE+"/api/v1/auth/captcha",params={"cache":"no-store"},headers=H,timeout=45)
    cap=g.json().get("payload") or {}
    res["cap_keys"]=list(cap.keys())
    if cap:
        rr,hx,hy=ncc(dec(cap["background"]),dec(cap["pieceImage"]))
        W,PW=int(cap["width"]),int(cap["piece"])
        tx=max(0,min(W-PW,int(hx)))
        body={"token":cap["token"],"x":tx,"trace":trace(tx)}
        chk=s.post(BASE+"/api/v1/auth/captcha/check",data=json.dumps(body),
                   headers={**H,"content-type":"application/json"},timeout=55)
        res["tries"].append({"ncc":[float(rr),int(hx),int(hy)],"sent_x":int(tx),"status":int(chk.status_code),"resp":str(chk.text)[:260]})
except Exception as ex:
    res["err"]=f"{type(ex).__name__}:{str(ex)[:180]}"

json.dump(res, open(OUTF,"w"), default=str)
print(json.dumps(res,default=str)[:1400])
