#!/usr/bin/env python3
"""QP account factory v1: create inbox -> solve captcha -> register -> confirm OTP."""
import base64, io, json, os, secrets, shutil, subprocess, sys, time
QDIR = os.environ.get('QPF_DIR') or os.path.dirname(os.path.abspath(__file__))
NODE = os.environ.get('NODE_BIN') or (shutil.which('node') or 'node')

from PIL import Image
import numpy as np
import requests

SU = "qp" + secrets.token_hex(4); SP = "qq" + secrets.token_hex(6)
REMOTE = bool(os.environ.get("QPF_DIR"))
PYPROX = (None if REMOTE else {"https": "socks5h://" + SU + ":" + SP + "@127.0.0.1:19050"})
import os as _osx
if _osx.environ.get("QPF_DIR"):
    PX = None                      # direct egress on remote box
else:
    PX = {"https": "socks5h://" + SU + ":" + SP + "@127.0.0.1:19050"}
B = "https://app.quantumproxies.io"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131 Safari/537.36"
H = {"accept": "application/json, text/plain, */*", "referer": B + "/register",
     "user-agent": UA, "origin": B}


def dec(u): return base64.b64decode(u.split(",", 1)[1])


def ncc(bgp, pcs):
    A = np.asarray(Image.open(io.BytesIO(bgp)).convert("L"), dtype=np.float32)
    pm = Image.open(io.BytesIO(pcs)); cr = pm.crop(pm.getbbox())
    T0 = np.asarray(cr.convert("L"), dtype=np.float32); al = np.asarray(cr.split()[-1], dtype=np.float32)
    m = (al > 110).astype(np.float32); th, tw = T0.shape
    tv = T0[m > 0]; T = (T0 - float(tv.mean())) * m / (float(tv.std()) + 1e-6)
    from numpy.fft import rfft2, irfft2
    ph, pwd = A.shape[0] + th - 1, A.shape[1] + tw - 1
    cv = irfft2(rfft2(A, s=(ph, pwd)) * rfft2(T[::-1, ::-1], s=(ph, pwd)), s=(ph, pwd))
    v = cv[th-1:, tw-1:]
    best = (-9, 30, 30)
    for i in np.argsort(-v.ravel())[:60]:
        y, x = int(i // v.shape[1]), int(i % v.shape[1]); win = A[y:y+th, x:x+tw]
        if win.shape != (th, tw): continue
        vv = win[m > 0]
        r = float(((win - float(vv.mean())) * m / (float(vv.std()) + 1e-6) * T).sum()) / m.sum()
        if r > best[0]: best = (r, x, y)
    return best


def mk_trace(xe):
    st = -(8 + secrets.randbelow(14)); ov = [0, -1, 1][secrets.randbelow(3)]
    npts = 92 + secrets.randbelow(26); dur = 1800 + secrets.randbelow(850)
    t = int(time.time()*1000) - dur - secrets.randbelow(200)
    ez = lambda u: (4*u**3 if u < .5 else 1 - ((-2*u+2)**3)/2)
    out = []
    for i in range(npts+1):
        jx = st + (xe+ov-st)*ez(i/npts) + (secrets.randbelow(160)-80)/170.0*(1-i/(npts+1))
        tt = t + int(dur*i/npts) + secrets.randbelow(11) - 5
        if out and tt <= out[-1]["t"]: tt = out[-1]["t"] + 1 + secrets.randbelow(13)
        out.append({"x": round(jx, 2), "t": tt})
    out.append({"x": float(max(0, xe)), "t": out[-1]["t"] + 10 + secrets.randbelow(24)})
    return out[:400]


def sign(body_str):
    r = subprocess.run([NODE, QDIR + "/qdsign3.js", body_str],
                       capture_output=True, text=True, timeout=25)
    for ln in (r.stdout or "").splitlines():
        if ln.startswith("RESULT"):
            d = json.loads(ln.replace("RESULT ", ""))
            return {"X-QD-TS": d["ts"], "X-QD-Token": d["token"]}
    print("[sign fail]", (r.stdout or "")[:120], (r.stderr or "")[:120])
    return None


class QPF:
    def __init__(self):
        self.s = requests.Session()

    def warm(self):
        try:
            self.s.get(B + "/register", headers={**H, "referer": "https://quantumproxies.io/"}, proxies=PYPROX, timeout=45)
        except Exception as e:
            print("[warm]", type(e).__name__)

    def solve_captcha(self, tries=6):
        for k in range(tries):
            g = self.s.get(B + "/api/v1/auth/captcha", params={"cache": "no-store"}, headers=H, proxies=PYPROX, timeout=45)
            if g.status_code != 200:
                print(f"[{k}] cap http {g.status_code}"); time.sleep(8); continue
            cap = g.json().get("payload") or {}
            rr, hx, hy = ncc(dec(cap["background"]), dec(cap["pieceImage"]))
            W, PW = int(cap["width"]), int(cap["piece"])
            tx = max(0, min(W-PW, int(hx)))
            bs = json.dumps({"token": cap["token"], "x": tx, "trace": mk_trace(tx)}, separators=(',', ':'), ensure_ascii=False)
            sig = sign(bs)
            if not sig:
                continue
            pause = 1.7 + secrets.randbelow(180)/100.0
            print(f"[{k}] ncc={rr:.3f} hole={hx},{hy} wait={pause:.1f}s")
            time.sleep(pause)
            chk = self.s.post(B + "/api/v1/auth/captcha/check", data=bs.encode(),
                              headers={**H, "content-type": "application/json", **sig}, proxies=PYPROX, timeout=55)
            txt = chk.text[:140].replace("\n", " ")
            print(f"[{k}] check -> {chk.status_code} {txt}")
            if '"ok":true' in chk.text.replace(' ', ''):
                return True
            time.sleep(9)
        return False

    def post_signed(self, path, obj_or_str, extra=None):
        bs = obj_or_str if isinstance(obj_or_str, str) else json.dumps(obj_or_str, separators=(',', ':'), ensure_ascii=False)
        sig = sign(bs)
        hdr = {**H, "content-type": "application/json", **(extra or {}), **(sig or {})}
        return self.s.post(B + path, data=bs.encode(), headers=hdr, proxies=PYPROX, timeout=60)


if __name__ == "__main__":
    EMAIL = sys.argv[1] if len(sys.argv) > 1 else f"qptest{secrets.token_hex(3)}@otpbxuyp3.tail.me"
    PW = sys.argv[2] if len(sys.argv) > 2 else ("Qz!" + secrets.token_urlsafe(9))
    q = QPF(); q.warm()
    ok = q.solve_captcha()
    print("[+] captcha:", ok)
    if ok:
        cands = [
            ("/api/v1/auth/signup", {"email": EMAIL, "password": PW, "confirmPassword": PW,
                                     "firstName": "Alex", "lastName": "Turner", "acceptTerms": True}),
            ("/api/v1/auth/register", {"email": EMAIL, "password": PW}),
            ("/api/v1/users", {"email": EMAIL, "password": PW}),
        ]
        for path, body in cands:
            try:
                r = q.post_signed(path, body)
                print(f"[reg] {path} -> {r.status_code} :: {r.text[:280].replace(chr(10),' ')}")
                if r.status_code < 300 and ('"' in r.text):
                    open("/home/gabri/.hermes/dionysus-pi/workspace-root/work/qpfactory/accounts.jsonl", "a").write(
                        json.dumps({"email": EMAIL, "pw": PW, "resp": r.text[:500], "ts": int(time.time())})+"\n")
                    break
            except Exception as ex:
                print(f"[reg] {path} EXC {type(ex).__name__}:{str(ex)[:90]}")
