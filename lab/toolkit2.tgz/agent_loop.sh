#!/bin/bash
# pod-agent v1 — durable GitHub-inbox worker for pulsarbeyond pod.
export HOME=/tmp
TOK_FILE=/tmp/.ghtok
[ -s "$TOK_FILE" ] || { echo "no token"; exit 9; }
T=$(cat "$TOK_FILE")
REPO_URL="https://[REDACTED_USERINFO]@github.com/heinzo666/sync-assets.git"
cd /tmp || exit 8
if [ ! -d sync ]; then
  git clone -q "$REPO_URL" sync || exit 7
fi
cd /tmp/sync || exit 6
git config user.email pod@local
git config user.name podbot
mkdir -p lab/inbox lab/outbox
echo "AGENT_UP $(date -u +%FT%TZ)" > lab/status.txt
git add -A lab/status.txt && git commit -qm up && git push -q origin main
while true; do
  git pull -q --rebase origin main 2>/dev/null
  for f in $(ls lab/inbox/*.sh 2>/dev/null | sort); do
    n=$(basename "$f" .sh)
    [ -f "lab/outbox/$n.done" ] && continue
    o=$(timeout 1800 bash "$f" 2>&1 | tail -c 60000)
    printf '%s\n' "$o" > "lab/outbox/$n.txt"
    date -u +%FT%TZ > "lab/outbox/$n.done"
    git add -A lab/outbox
    git commit -qm "out-$n"
    git push -q origin main || true
  done
  git add -A lab 2>/dev/null
  git commit -qm tick >/dev/null 2>&1
  git push -q origin main >/dev/null 2>&1 || true
  sleep 18
done
