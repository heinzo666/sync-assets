#!/usr/bin/env python3
"""QP factory v3 — register + activate (free trial + credentials) atomically.
Run on the pod: QPF_DIR=/tmp/mint NODE_BIN=... MINT_TARGET=n python mint_v3.py"""
import base64, json, os, secrets, sys, time

sys.path.insert(0, "/tmp/mint")
from qp_factory_v1 import QPF, dec, ncc, mk_trace, PYPROX   # noqa

DOMAIN = "otpbxuyp3.tail.me"
TARGET = int(os.environ.get("MINT_TARGET", "10"))
PREFIX = os.environ.get("MINT_PREFIX", "qa")
OUT = "/tmp/mint/accounts3.jsonl"
LOG = "/tmp/mint/log3.txt"
GHTOK = open("/tmp/.ghtok").read().strip()
REPO = "heinzo666/sync-assets"
GHPATH = "lab/qp_accounts3.jsonl"
B = "https://app.quantumproxies.io"
CAPURL = B + "/api/v1/auth/captcha"
HDRS = {"accept": "*/*", "referer": B + "/register",
        "user-agent": "Mozilla/5.0 Chrome/131"}
HD = {"accept": "application/json,*/*", "referer": B + "/dashboard",
      "user-agent": "Mozilla/5.0 Chrome/131"}


def log(m):
    ln = f"[{time.strftime('%H:%M:%S')}] {m}"
    print(ln, flush=True)
    open(LOG, "a").write(ln + "\n")


def gh_push(text):
    try:
        import requests
        hh = {"Authorization": "Bearer " + GHTOK, "Accept": "application/vnd.github+json"}
        url = f"https://api.github.com/repos/{REPO}/contents/{GHPATH}"
        g = requests.get(url, headers=hh, timeout=25)
        sha = g.json().get("sha") if g.status_code == 200 else None
        body = {"message": f"qp3 {len(text.splitlines())}accts",
                "content": base64.b64encode(text.encode()).decode()}
        if sha:
            body["sha"] = sha
        return requests.put(url, headers=hh, json=body, timeout=30).status_code
    except Exception as ex:
        return f"ERR:{type(ex).__name__}"


def load():
    out = []
    if os.path.exists(OUT):
        for ln in open(OUT):
            ln = ln.strip()
            if ln:
                try:
                    out.append(json.loads(ln))
                except Exception:
                    pass
    return out


def save(lst):
    open(OUT, "w").write("\n".join(json.dumps(r) for r in lst) + "\n")


def gget(q, path):
    try:
        r = q.s.get(B + path, headers=HD, proxies=PYPROX, timeout=40)
        txt = r.text[:900].replace("\n", " ")
        return {"code": r.status_code, "body": txt}
    except Exception as ex:
        return {"err": type(ex).__name__, "msg": str(ex)[:80]}


def gpost(q, path, obj=None):
    """Signed POST."""
    try:
        r = q.post_signed(path, obj if obj is not None else {}, extra={"referer": B + "/settings?tab=free-trial"})
        return {"code": r.status_code, "body": r.text[:700].replace("\n", " ")}
    except Exception as ex:
        return {"err": type(ex).__name__, "msg": str(ex)[:80]}


def register(idx, tries=4):
    em = f"{PREFIX}{idx}{secrets.token_hex(2)}@{DOMAIN}"
    pw = "Qz!" + secrets.token_urlsafe(8) + "9aA"
    for k in range(tries):
        try:
            q = QPF(); q.warm()
            g = q.s.get(CAPURL, params={"cache": "no-store"}, headers=HDRS, proxies=PYPROX, timeout=45)
            if g.status_code != 200:
                time.sleep(18); continue
            cap = g.json()["payload"]
            rr, hx, hy = ncc(dec(cap["background"]), dec(cap["pieceImage"]))
            W, PWpx = int(cap["width"]), int(cap["piece"])
            tx = max(0, min(W - PWpx, int(hx)))
            tr = mk_trace(tx)
            time.sleep(1.7 + secrets.randbelow(170) / 100.0)
            r = q.post_signed("/api/v1/auth/signup",
                              {"email": em, "password": pw,
                               "captcha": {"token": cap["token"], "x": tx, "trace": tr}})
            low = r.text.lower()
            log(f"{em} [{k}] reg={r.status_code} ncc={rr:.2f}")
            if r.status_code < 300 and '"response"' in r.text.replace(" ", ""):
                rec = {"email": em, "pw": pw, "ts": int(time.time()), "box": "pod-v3",
                       "registered": True, "session_cookies": len(q.s.cookies)}
                act = activate(q, rec)
                if act:
                    return rec
                return rec          # keep account even if activation failed
            if "guard" in low or "too-fast" in low:
                time.sleep(12 + secrets.randbelow(12)); continue
            if "rate" in low or r.status_code == 429:
                time.sleep(85 + secrets.randbelow(50)); continue
            time.sleep(8)
        except Exception as ex:
            log(f"{em} exc {type(ex).__name__}:{str(ex)[:70]}")
            time.sleep(10)
    return None


def activate(q, rec):
    """Claim free trial + discover credential surface on the live session."""
    info = {}
    info["ft_status"] = gget(q, "/api/v1/user/free-trial/status")
    info["me"] = gget(q, "/api/v1/user")
    info["bal"] = gget(q, "/api/v1/user/balance-history?limit=1")
    info["claim"] = gpost(q, "/api/v1/user/free-trial/claim")
    # some surfaces live under bare /api/v1 instead of /user
    for alt in ("/api/v1/residential-basic/whitelist", "/api/v1/user/residential-basic/whitelist"):
        info.setdefault("wl", []).append({alt: gget(q, alt)})
    for alt in ("/api/v1/generator/countries", "/api/v1/user/generator/countries"):
        info.setdefault("gen", []).append({alt: gget(q, alt)})
    rec["activation"] = info
    ok = any(str(info[k].get("code")) == "200" for k in ("ft_status", "me", "claim") if isinstance(info.get(k), dict))
    rec["activated"] = bool(ok)
    log(f"  ACT {rec['email']} ft={info['ft_status'].get('code')} "
        f"claim={info['claim'].get('code')} me={info['me'].get('code')} -> {rec['activated']}")
    return rec["activated"]


def main():
    accs = load()
    idx = len(accs) + 20          # offset to avoid collisions with earlier loops
    while len([a for a in accs if a.get("activated")]) < TARGET:
        rec = register(idx)
        if rec:
            accs.append(rec)
            save(accs)
            st = gh_push(open(OUT).read())
            log(f"SAVED #{len(accs)} {rec['email']} activated={rec.get('activated')} pushed={st}")
        else:
            log(f"#{idx} registration failed; backoff")
            time.sleep(35)
        idx += 1
        gap = 55 + secrets.randbelow(35)
        log(f"...sleep {gap}s")
        time.sleep(gap)
    log("DONE_V3")
    gh_push(open(OUT).read())


if __name__ == "__main__":
    main()
