#!/usr/bin/env python3
"""QP factory v2 — mint trial accounts sequentially on the pod.
Target: fill /tmp/mint/accounts.jsonl up to TARGET rows (default 10).
Pushes the list to GH after every success (best-effort)."""
import base64, json, os, secrets, sys, time

sys.path.insert(0, "/tmp/mint")
from qp_factory_v1 import QPF, dec, ncc, mk_trace, PYPROX   # noqa

DOMAIN = "otpbxuyp3.tail.me"
TARGET = int(os.environ.get("MINT_TARGET", "10"))
ACCT = "/tmp/mint/accounts.jsonl"
LOG = "/tmp/mint/log.txt"
GHTOK = open("/tmp/.ghtok").read().strip()
REPO = "heinzo666/sync-assets"
PATH = "lab/qp_accounts.jsonl"


def log(msg):
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def load():
    out = []
    if os.path.exists(ACCT):
        for ln in open(ACCT):
            ln = ln.strip()
            if not ln:
                continue
            try:
                out.append(json.loads(ln))
            except Exception:
                pass
    return out


def save(lst):
    with open(ACCT, "w") as f:
        for r in lst:
            f.write(json.dumps(r) + "\n")


def gh_push(text):
    try:
        import requests
        Hh = {"Authorization": "Bearer " + GHTOK, "Accept": "application/vnd.github+json"}
        url = f"https://api.github.com/repos/{REPO}/contents/{PATH}"
        sha = None
        g = requests.get(url, headers=Hh, timeout=25)
        if g.status_code == 200:
            sha = g.json().get("sha")
        body = {"message": f"qp accounts {len(text.splitlines())}",
                "content": base64.b64encode(text.encode()).decode()}
        if sha:
            body["sha"] = sha
        p = requests.put(url, headers=Hh, json=body, timeout=30)
        return p.status_code
    except Exception as ex:
        return f"ERR:{type(ex).__name__}"


def one(idx, tries=4):
    """Attempt to register a single account. Returns record or None."""
    em_base = f"qz{idx}{secrets.token_hex(2)}@{DOMAIN}"
    pw = "Qz!" + secrets.token_urlsafe(8) + "9aA"
    for k in range(tries):
        try:
            q = QPF()
            q.warm()
            CAPURL = "https://app.quantumproxies.io/api/v1/auth/captcha"
            g = q.s.get(CAPURL, params={"cache": "no-store"},
                        headers={"accept": "*/*", "referer": "https://app.quantumproxies.io/register",
                                 "user-agent": "Mozilla/5.0 Chrome/131"}, proxies=PYPROX, timeout=45)
            if g.status_code != 200:
                log(f"{em_base} cap http {g.status_code}; sleep 20"); time.sleep(20); continue
            cap = g.json()["payload"]
            rr, hx, hy = ncc(dec(cap["background"]), dec(cap["pieceImage"]))
            W, PWpx = int(cap["width"]), int(cap["piece"])
            tx = max(0, min(W - PWpx, int(hx)))
            tr = mk_trace(tx)
            think = 1.7 + secrets.randbelow(170) / 100.0
            time.sleep(think)
            payload = {"email": em_base, "password": pw,
                       "captcha": {"token": cap["token"], "x": tx, "trace": tr}}
            r = q.post_signed("/api/v1/auth/signup", payload)
            txt = r.text[:220].replace("\n", " ")
            log(f"{em_base} [{k}] ncc={rr:.2f} x={tx} -> {r.status_code} :: {txt}")
            if r.status_code < 300 and '"response"' in r.text.replace(" ", ""):
                rec = {"email": em_base, "pw": pw, "status": "OK",
                       "ts": int(time.time()), "box": "pod", "variant": "inline_captcha"}
                return rec
            low = r.text.lower()
            if "guard" in low:
                time.sleep(12 + secrets.randbelow(13))
                continue
            if "too-fast" in low:
                time.sleep(6); continue
            if "already" in low or "exists" in low:
                break                      # email collision, next email
            if "rate" in low or r.status_code == 429:
                time.sleep(90 + secrets.randbelow(61)); continue
            time.sleep(8)
        except Exception as ex:
            log(f"{em_base} [{k}] exc {type(ex).__name__}:{str(ex)[:80]}")
            time.sleep(10)
    return None


def main():
    accs = load()
    seen = {a["email"] for a in accs}
    idx = len(accs) + 1
    while len(accs) < TARGET:
        rec = one(idx, tries=4)
        if rec and rec["email"] not in seen:
            accs.append(rec); seen.add(rec["email"])
            save(accs)
            st = gh_push(open(ACCT).read())
            log(f"MINTED #{len(accs)} {rec['email']} | pushed={st}")
        else:
            log(f"#{idx} failed this round; backing off 40s")
            time.sleep(40)
        idx += 1
        gap = 55 + secrets.randbelow(35)
        log(f"...sleep {gap}s before next")
        time.sleep(gap)
    log(f"DONE total={len(accs)}")
    gh_push(open(ACCT).read())


if __name__ == "__main__":
    main()
