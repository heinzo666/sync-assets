#!/usr/bin/env python3
"""QP browser login probe v2 — correct selectors, precise waits, rich diagnostics."""
import json, sys, time

B = "https://app.quantumproxies.io"


def main():
    em, pw = sys.argv[1], sys.argv[2]
    from playwright.sync_api import sync_playwright

    nets = []

    def keep(r):
        u = r.url
        if ("/api/" in u or u.rstrip("/").endswith("/login")) and \
           not u.endswith((".css", ".png", ".woff2", ".svg", ".js")):
            rec = {"m": r.method, "u": u[:170]}
            try:
                pd = r.post_data
                if pd:
                    rec["body"] = pd[:700]
            except Exception:
                pass
            na = r.headers.get("next-action")
            if na:
                rec["next_action"] = na[:48]
            nets.append(rec)

    rep = {}
    with sync_playwright() as p:
        br = p.chromium.launch(headless=True,
                               args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
        ctx = br.new_context(locale="en-US",
                             user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                         "AppleWebKit/537.36 (KHTML, like Gecko) "
                                         "Chrome/131.0.0.0 Safari/537.36"),
                             viewport={"width": 1440, "height": 810})
        pg = ctx.new_page()
        pg.on("request", keep)
        try:
            pg.goto(B + "/login", wait_until="domcontentloaded", timeout=60000)
            pg.wait_for_timeout(3000)
            pg.fill("input[name=email]", em, timeout=15000)
            pg.fill("input[name=password]", pw, timeout=10000)
            print("[fields ok]")

            btn = pg.query_selector("//button[normalize-space()='Log In']") or \
                  pg.query_selector("button:has-text('Log In')")
            if not btn:
                raise RuntimeError("Login button not found")
            btn.click(timeout=12000)
            print("[clicked Log In]")

            t0 = time.time(); tok = None; cap_seen = False
            while time.time() - t0 < 75:
                pg.wait_for_timeout(900)
                if pg.url != B + "/login":
                    break
                ls = pg.evaluate("localStorage.getItem('token')")
                if ls:
                    tok = ls
                    break
                # genuine slider detection: canvas/img pair inside a captcha box
                cand = pg.query_selector_all("img[src^='data:image'], canvas")
                big = [c for c in cand if c.is_visible()]
                if len(big) >= 1:
                    txt = ""
                    par = pg.query_selector("text=/Slide|Puzzle|Verify you/i")
                    if par:
                        txt = (par.inner_text() or "")[:60]
                    if txt or len(big) >= 2:
                        cap_seen = True
                        print("[captcha-ish]", txt, "nodes:", len(big))
                        break
            rep["cap_seen"] = cap_seen
            rep["url_after"] = pg.url
            rep["tok_now"] = bool(tok)
            pg.wait_for_timeout(2500)
            if not tok:
                tok = pg.evaluate("localStorage.getItem('token')")
            rep["ls"] = pg.evaluate("Object.fromEntries(Object.entries(localStorage))")
            rep["cookies"] = [(c["name"], c["value"][:24]) for c in ctx.cookies()]
            alerts = []
            for sel in ("[role=alert]", "[data-sonner-toast]", ".Toastify__toast-body", "li[data-type=error]"):
                for el in pg.query_selector_all(sel)[:4]:
                    try:
                        tx = (el.inner_text() or "").strip().replace("\n", " ")
                        if tx:
                            alerts.append(tx[:110])
                    except Exception:
                        pass
            rep["alerts"] = list(dict.fromkeys(alerts))[:6]
            pg.screenshot(path="/tmp/browser_v2.png")

            if pg.url != B + "/login" or rep["ls"].get("token"):
                apis = ["/api/v1/user/free-trial/status", "/api/v1/user"]
                got = {}
                for a in apis:
                    got[a] = pg.evaluate(
                        """async (path)=>{try{const r=await fetch(path,{credentials:'include',
                           headers:{accept:'application/json,*/*'}});
                           return {code:r.status, body:(await r.text()).slice(0,260)};}
                           catch(e){return {err:String(e).slice(0,80)}}}""", a)
                rep["apis"] = got
        except Exception as ex:
            rep["exc"] = f"{type(ex).__name__}: {str(ex)[:200]}"
        br.close()

    rep["nets"] = nets[-14:]
    open("/tmp/browser_result.json", "w").write(json.dumps(rep))
    short = dict(rep); short.pop("nets", None); short.pop("cookies", None)
    print("SHORT", json.dumps(short)[:1400])
    print("NETS", json.dumps(nets[-8:])[:1600])


if __name__ == "__main__":
    main()
