import json,sys,time
sys.path.insert(0,'.')
from qp_factory_v1 import QPF, dec, ncc, mk_trace, sign
EMAIL=sys.argv[1]; PW=sys.argv[2]
q=QPF(); q.warm()
# fetch fresh challenge ONLY (no pre-check); embed solution into signup itself
g=q.s.get("https://app.quantumproxies.io/api/v1/auth/captcha",params={"cache":"no-store"},
          headers={"accept":"*/*","referer":"https://app.quantumproxies.io/register",
                   "user-agent":"Mozilla/5.0 Chrome/131"}, proxies=None if False else __import__('qp_factory_v1').PYPROX, timeout=45)
cap=g.json()["payload"]
rr,hx,hy=ncc(dec(cap["background"]),dec(cap["pieceImage"]))
W,PWpx=int(cap["width"]),int(cap["piece"]); tx=max(0,min(W-PWpx,int(hx)))
tr=mk_trace(tx)
print(f"[fresh] ncc={rr:.3f} hole=({hx},{hy}) x={tx}")
pause=2.0+ (secrets_rand:=__import__('secrets').randbelow(120))/100.0
time.sleep(pause)
variants=[
 ("A_full_inline", {"email":EMAIL,"password":PW,
     "captcha":{"token":cap["token"],"x":tx,"trace":tr}}),
 ("B_x_only",      {"email":EMAIL,"password":PW,"captcha":{"x":tx}}),
 ("C_topnames",    {"email":EMAIL,"password":PW,"captchaToken":cap["token"],"captchaX":tx}),
]
for name,body in variants:
    r=q.post_signed("/api/v1/auth/signup", body)
    print(f"[{name}] {r.status_code} :: {r.text[:420].replace(chr(10),' ')}")
    try:
        j=r.json()
        if j.get("type")=="response" or r.status_code<300: 
            open('/tmp/labv/REG_OK.txt','w').write(json.dumps({"variant":name,"resp":j,"email":EMAIL,"pw":PW}))
            print("*** SUCCESS ***",name); break
    except Exception: pass
    time.sleep(6)
