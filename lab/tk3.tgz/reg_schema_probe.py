import json,os,secrets,sys,time
sys.path.insert(0,'.')
from qp_factory_v1 import QPF, sign
EMAIL=sys.argv[1]; PW=sys.argv[2]
q=QPF(); q.warm()
ok=q.solve_captcha(); print("CAP",ok)
if not ok: sys.exit(1)
big={"email":EMAIL,"password":PW,"confirmPassword":PW,"passwordConfirm":PW,
 "firstName":"Alex","lastName":"Turner","surname":"Turner","name":"Alex Turner",
 "token":"X","captchaToken":"X","captcha_token":"X","captcha":{"token":"X"},
 "turnstileToken":"X","acceptTerms":True,"terms":True,"acceptedTerms":True,
 "gdprConsent":True,"newsletter":False,"promoCode":"","referral":"","phone":""}
r=q.post_signed("/api/v1/auth/signup", big)
body=r.text[:2400].replace("\n"," ")
print("STATUS",r.status_code); print("BODY_FULL:",body)
# minimal second attempt same session if first was schema noise only
try:
    j=json.loads(r.text)
    pl=j.get("payload")
    known_bad=[x["context"]["key"] for x in pl] if isinstance(pl,list) else []
except Exception: known_bad=[]
minb={k:v for k,v in {"email":EMAIL,"password":PW}.items()}
r2=q.post_signed("/api/v1/auth/signup", minb)
print("MIN_STATUS",r2.status_code); print("MIN_BODY:",r2.text[:1400].replace("\n"," "))
open('reg_probe_result.json','w').write(json.dumps({"known_bad":known_bad,"full":r.text[:3000],"mini":r2.text[:1500]}))
