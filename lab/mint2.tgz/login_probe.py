import json,sys,time,requests
sys.path.insert(0,'.')
from qp_factory_v1 import QPF, sign, PYPROX
EMAIL=open('/tmp/labv/RUNINFO').read().strip().split('=',1)[1] if False else sys.argv[1]
PW=sys.argv[2]
q=QPF(); q.warm()
r=q.post_signed("/api/v1/auth/login", {"email":EMAIL,"password":PW})
print("LOGIN_STATUS",r.status_code); print("LOGIN_BODY:",r.text[:400].replace("\n"," "))
try: tok=(r.json().get("payload") or {}).get("token") or r.json().get("token")
except Exception: tok=None
if not tok:
    try: tok=r.cookies.get("sc_sid")
    except Exception: pass
print("TOKEN?",bool(tok))
H={"accept":"application/json,*/*","referer":"https://app.quantumproxies.io/",
   "user-agent":"Mozilla/5.0 Chrome/131"}
paths=["/api/v1/users/me","/api/v1/user","/api/v1/account","/api/v1/profile",
       "/api/v1/subscriptions","/api/v1/subscription","/api/v1/plans","/api/v1/products",
       "/api/v1/residential","/api/v1/proxies","/api/v1/proxy-credentials","/api/v1/traffic",
       "/api/v1/wallet","/api/v1/billing","/api/v1/trial"]
for p in paths:
    try:
        hh={**H};
        if tok and isinstance(tok,str): hh["Authorization"]="Bearer "+tok
        rr=q.s.get("https://app.quantumproxies.io"+p,headers=hh,proxies=PYPROX,timeout=40)
        t=rr.text[:200].replace("\n"," ")
        mark="OK" if rr.status_code==200 and len(rr.text)>30 else ""
        print(f"{mark} {p} -> {rr.status_code} {t}")
    except Exception as ex:
        print(f"ERR {p} {type(ex).__name__}:{str(ex)[:60]}")
