#!/usr/bin/env python3
"""QP activation orchestrator v1 — runs ON THE POD.

Flow per account: mailhook addr -> browser signup (auto slider) -> email verify ->
login -> trial status/claim probe. Env:
  STAGE = dragdump | full        (default full)
Usage: python qp_orch.py <localpart>          # creates address itself via mailhook
"""
import json, os, secrets, sys, time

B = "https://app.quantumproxies.io"
MH_BASE = "https://app.mailhook.co"
MH_AGENT = "mh_uZ4SuKI4Q1OJ1zju9aVVJqnS"



def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


# ---------- mailhook ----------
def mh_req(method, path, body=None):
    import urllib.request
    import os as _o
    key = _o.environ.get("MH_API_KEY") or open("/tmp/mh.key").read().strip()
    req = urllib.request.Request(MH_BASE + path, method=method,
                                 data=(json.dumps(body).encode() if body else None),
                                 headers={"Content-Type": "application/json",
                                          "X-Agent-ID": MH_AGENT, "X-API-Key": key})
    with urllib.request.urlopen(req, timeout=35) as r:
        return json.loads(r.read().decode())


def mh_new(local_hint):
    """Random address on our domain."""
    dom = int(os.environ.get("MH_DOMAIN_ID", "18666"))
    for _ in range(3):
        try:
            r = mh_req("POST", "/api/v1/email_addresses/random",
                       {"domain_id": str(dom), "metadata": {"task": local_hint}})
            d = r.get("data") or {}
            attrs = d.get("attributes") or {}
            if d.get("id"):
                return {"ea": d["id"], "email": attrs.get("email")}
        except Exception as ex:
            log(f"mh_new err {type(ex).__name__}:{str(ex)[:70]}")
        time.sleep(4)
    raise RuntimeError("mailhook address creation failed")


def mh_msgs(ea):
    r = mh_req("GET", f"/api/v1/email_addresses/{ea}/inbound_emails")
    return r.get("data") or []


def mh_detail(ea, mid):
    r = mh_req("GET", f"/api/v1/email_addresses/{ea}/inbound_emails/{mid}")
    return ((r.get("data") or {}).get("attributes")) or {}


def find_code_or_link(ea, deadline_s=150):
    """Poll newest inbound mail; return {'code':..,'links':[..],'subj':..} once something arrives."""
    seen_before = set()
    t0 = time.time()
    while time.time() - t0 < deadline_s:
        try:
            msgs = mh_msgs(ea)
        except Exception as ex:
            log(f"mh_msgs err {type(ex).__name__}")
            msgs = []
        new = [m for m in msgs if m.get("id") not in seen_before]
        if len(msgs) == len(new) and msgs:
            # nothing we've already scanned left unseen
            pass
        if new:
            for m in reversed(new):     # newest last in typical order; scan all anyway
                try:
                    a = mh_detail(ea, m["id"])
                except Exception:
                    continue
                blob = " ".join(str(a.get(k) or "") for k in ("subject", "text_body", "html_body"))
                import re
                codes = re.findall(r"\b(\d{6})\b", blob)
                links = re.findall(r"https?://[^\s\"'<>)\]]+", blob)
                subj = a.get("subject")
                log(f"mail from={a.get('from_email')} subj={subj} codes={codes[:2]} links={len(links)}")
                if codes or links or subj:
                    return {"code": (codes[-1] if codes else None),
                            "links": links[:6], "subj": subj}
        seen_before.update(m.get("id") for m in msgs)
        time.sleep(9)
    return None


# ---------- captcha solving for slider drag ----------
def ncc_x(bgpng_bytes, pcbytes):
    import io, numpy as np
    from PIL import Image
    def arr(b):
        im = Image.open(io.BytesIO(b)).convert("RGBA")
        return np.asarray(im).astype(np.float32), im.size
    bg, bs = arr(bgpng_bytes)
    pc, ps = arr(pcbytes)
    alpha = pc[:, :, 3] > 60
    ys, xs = np.where(alpha)
    pc_crop = pc[ys.min():ys.max()+1, xs.min():xs.max()+1]
    pmask = pc_crop[:, :, 3:4] > 100
    rgb = pc_crop[:, :, :3].copy()
    rr = rgb * pmask
    best, bx, by = -9, 0, 0
    H, W = bg.shape[0], bg.shape[1]
    h, w = rr.shape[0], rr.shape[1]
    norm = np.sqrt((rr ** 2).sum()) + 1e-6
    step = max(1, (W - w) // 220)
    for x in range(0, W - w, step):
        win = bg[:, x:x+w, :3]
        num = (win * rr).sum()
        den = (np.sqrt((win ** 2).sum(axis=(0, 1))) + 1e-6) * norm
        sc = float(num / den)
        if sc > best:
            best, bx = sc, x
    return best, int(bx), w


def main():
    tag = sys.argv[1] if len(sys.argv) > 1 else f"or{secrets.token_hex(2)}"
    stage = os.environ.get("STAGE", "full")
    log(f"=== orch {tag} stage={stage} ===")

    acc = mh_new(tag)
    em, ea = acc["email"], acc["ea"]
    pw = "Qz!" + secrets.token_urlsafe(8) + "9aA"
    log(f"addr {em} ea={ea}")
    rec = {"email": em, "pw": pw, "ea": ea, "ts": int(time.time()), "stages": {}}

    cap_json_log = {}

    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        br = p.chromium.launch(headless=True,
                               args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
        ctx = br.new_context(locale="en-US",
                             user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                                         "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"),
                             viewport={"width": 1440, "height": 810})

        def on_resp(r):
            u = r.url
            if "/api/v1/auth/captcha" in u and "check" not in u:
                try:
                    j = r.json(); pl = j.get("payload") or {}
                    if pl.get("background") and pl.get("pieceImage"):
                        cap_json_log.clear(); cap_json_log.update(pl)
                        log("captured live captcha challenge json")
                except Exception:
                    pass

        pg = ctx.new_page()
        pg.on("response", on_resp)

        # ---- SIGNUP PAGE ----
        pg.goto(B + "/register", wait_until="domcontentloaded", timeout=60000)
        pg.wait_for_timeout(2500)
        ins = pg.eval_on_selector_all("input", "els=>els.map(e=>({n:e.name,t:e.type}))")
        log(f"reg inputs {ins}")
        rec["stages"]["inputs"] = ins

        pg.fill("input[name=email]", em, timeout=15000)
        psel = "input[name=password]" if pg.query_selector("input[name=password]") else \
               ("input[name*=pass i]" if pg.query_selector("input[name*=pass i]") else None)
        if not psel:
            rec["error"] = "no password field"; br.close(); json_dump(rec); return
        pg.fill(psel, pw, timeout=8000)
        cpw = pg.query_selector("input[name=confirmPassword]")
        if cpw:
            cpw.fill(pw)
        for cb in pg.query_selector_all("input[type=checkbox]"):
            if not cb.is_checked():
                try:
                    cb.check(timeout=3000)
                except Exception:
                    pass

        btn = pg.query_selector("//button[contains(normalize-space(),'Create') or contains(normalize-space(),'Sign Up') or contains(normalize-space(),'Register')]") \
              or pg.query_selector("button[type=submit]:not(:has-text('English'))")
        btn.click(timeout=12000)
        log("submitted signup")

        # ---- CAPTCHA LOOP ----
        solved_once = False
        t0 = time.time()
        while time.time() - t0 < 90:
            pg.wait_for_timeout(900)
            cur = pg.url
            if "/login" in cur or "/dashboard" in cur or "verify" in cur.lower():
                break
            if cap_json_log and not solved_once:
                log("solving slider ...")
                import base64
                try:
                    score, xpx, wpc = ncc_x(base64.b64decode(cap_json_log["background"].split(",")[-1]),
                                            base64.b64decode(cap_json_log["pieceImage"].split(",")[-1]))
                    log(f"ncc={score:.3f} xpx={xpx} piece_w={wpc} bgw={cap_json_log.get('width')}")
                    # find displayed bg/piece images
                    imgs = [i for i in pg.query_selector_all("img") if (i.get_attribute("src") or "").startswith("data:image")]
                    bb = None
                    for i in imgs:
                        b = i.bounding_box()
                        if b and b["width"] > 180:
                            bb = b; break
                    knobs = [k for sel in ("[role=slider]", ".react-slider", "[draggable=true]",
                                           "div[class*=handle i]", "div[class*=knob i]", "button[class*=slider i]")
                             for k in pg.query_selector_all(sel)]
                    kb = None
                    for k in knobs:
                        b = k.bounding_box()
                        if b:
                            kb = b; break
                    rec["stages"]["geom"] = {"bb": bb, "kb": kb, "n_imgs": len(imgs)}
                    if bb and kb:
                        sx = kb["x"] + kb["width"] / 2; sy = kb["y"] + kb["height"] / 2
                        dx = xpx * (bb["width"] / float(cap_json_log["width"]))
                        pg.mouse.move(sx, sy); pg.mouse.down()
                        steps = 28
                        for st in range(1, steps + 1):
                            fx = sx + dx * st / steps
                            fy = sy + ((-1) ** st) * 0.6
                            pg.mouse.move(fx, fy)
                            pg.wait_for_timeout(22 + (st % 5))
                        pg.mouse.up(); solved_once = True
                        log(f"dragged to +{dx:.0f}px (scale {bb['width']/float(cap_json_log['width']):.2f})")
                        pg.wait_for_timeout(2600)
                except Exception as ex:
                    log(f"solve exc {type(ex).__name__}:{str(ex)[:80]}")
        rec["stages"]["url_post_signup"] = pg.url
        lsnow = pg.evaluate("Object.fromEntries(Object.entries(localStorage))")
        rec["stages"]["ls_signup"] = lsnow
        log(f"post-signup url={pg.url} tok={'token' in lsnow}")
        pg.screenshot(path=f"/tmp/orch_{tag}_signup.png")

        if stage == "dragdump":
            html = ""
            el = pg.query_selector("[class*=captcha i],[id*=captcha i]")
            if el:
                html = (el.inner_html() or "")[:1200]
            rec["stages"]["cap_html"] = html.replace("\n", " ")
            br.close(); json_dump(rec); return

        # ---- EMAIL VERIFY ----
        got = find_code_or_link(ea, 170)
        rec["stages"]["mail"] = got
        if got:
            link = None
            for l in got.get("links") or []:
                if any(k in l for k in ("verify", "confirm", "activate")):
                    link = l; break
            try:
                if link:
                    pg.goto(link, wait_until="domcontentloaded", timeout=45000)
                    log(f"opened verify link -> {pg.url}")
                elif got.get("code"):
                    pg.goto(B + "/verify-email", wait_until="domcontentloaded", timeout=45000)
                    pg.wait_for_timeout(1600)
                    inp = pg.query_selector("input[inputmode=numeric], input[maxlength='6'], input[name*=code i]")
                    if inp:
                        inp.fill(got["code"])
                        sb = pg.query_selector("button[type=submit]:not(:has-text('English'))")
                        if sb:
                            sb.click()
                        log("submitted verify code")
                pg.wait_for_timeout(3500)
            except Exception as ex:
                log(f"verify step exc {type(ex).__name__}:{str(ex)[:80]}")

        # ---- LOGIN ----
        try:
            pg.goto(B + "/login", wait_until="domcontentloaded", timeout=50000)
            pg.wait_for_timeout(2800)
            pg.fill("input[name=email]", em, timeout=12000)
            pg.fill("input[name=password]", pw, timeout=8000)
            lb = pg.query_selector("//button[normalize-space()='Log In']") or pg.query_selector("button:has-text('Log In')")
            lb.click(timeout=12000)
            t1 = time.time()
            while time.time() - t1 < 65:
                pg.wait_for_timeout(950)
                if pg.evaluate("localStorage.getItem('token')") or "/dashboard" in pg.url:
                    break
            tok = pg.evaluate("localStorage.getItem('token')")
            rec["stages"]["login_url"] = pg.url
            rec["stages"]["token"] = bool(tok)
            if tok:
                rec["stages"]["token_preview"] = str(tok)[:26]
            alerts = []
            for sel in ("[role=alert]", "[data-sonner-toast]"):
                for el in pg.query_selector_all(sel)[:3]:
                    try:
                        alerts.append(((el.inner_text() or "").strip().replace("\n", " "))[:110])
                    except Exception:
                        pass
            rec["stages"]["alerts_login"] = list(dict.fromkeys(alerts))[:4]

            # ---- PROBE USER APIS IN-PAGE (with token attached if present) ----
            apis = {}
            if pg.url != B + "/login" or tok:
                probes = ["/api/v1/user/free-trial/status", "/api/v1/user",
                          "/api/v1/residential-basic/whitelist"]
                for a in probes:
                    apis[a] = pg.evaluate(
                        """async (path)=>{try{
                           const t=localStorage.getItem('token');
                           const h=t?{authorization:'Bearer '+t,accept:'application/json,*/*'}
                                   :{accept:'application/json,*/*'};
                           const r=await fetch(path,{credentials:'include',headers:h});
                           return {code:r.status,body:(await r.text()).slice(0,320)};}
                           catch(e){return{err:String(e).slice(0,80)}}}""", a)
            rec["stages"]["apis"] = apis
        except Exception as ex:
            rec["stages"]["login_exc"] = f"{type(ex).__name__}:{str(ex)[:140]}"

        pg.screenshot(path=f"/tmp/orch_{tag}_end.png")
        br.close()

    json_dump(rec)


def json_dump(rec):
    outp = "/tmp/orch_results.jsonl"
    with open(outp, "a") as f:
        f.write(json.dumps(rec) + "\n")
    log("RECORD " + json.dumps({k: rec[k] for k in ("email", "pw", "ea") if k in rec}))
    short = {k: v for k, v in rec.items() if k != "stages"}
    st = rec.get("stages", {})
    short["stages_summary"] = {
        "url_signup": st.get("url_post_signup"), "tok": st.get("token"),
        "login_url": st.get("login_url"), "mail_subj": (st.get("mail") or {}).get("subj"),
        "api_codes": {k: v.get("code") for k, v in (st.get("apis") or {}).items()},
        "geom": st.get("geom"), "alerts": st.get("alerts_login"),
        "login_exc": st.get("login_exc"), "error": rec.get("error"),
    }
    log("SUMMARY " + json.dumps(short["stages_summary"])[:700])


if __name__ == "__main__":
    main()
